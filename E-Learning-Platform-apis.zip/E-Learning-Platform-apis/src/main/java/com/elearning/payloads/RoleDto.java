package com.elearning.payloads;

import lombok.Data;

@Data
public class RoleDto {
	
	private int id;
	private String name;

}
