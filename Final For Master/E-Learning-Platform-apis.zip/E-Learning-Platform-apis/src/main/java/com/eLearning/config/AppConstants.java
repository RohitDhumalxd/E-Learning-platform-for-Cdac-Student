package com.eLearning.config;

public class AppConstants {
	public static final Integer ADMIN_USER=501;
	public static final Integer NORMAL_USER=502;
}
