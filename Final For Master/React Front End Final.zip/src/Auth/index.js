// is Logged in

export const isLoggedIn=()=>{
    let data=localStorage.getItem("data")
    if (data!= null) {
        return true;
    }
    else{
        return false;
    }
};

// do Login data ---> set to local storage
export const doLogin=(data,next)=>{
   localStorage.setItem("data",JSON.stringify(data));
   next();
};


// Do Logout ---> remove data/JWT-token from local Storage

export const doLogout=(next)=>{
    localStorage.removeItem("data");
    next();
};

// to get current User

export const getCurrentUserDetails=()=>{
    if (isLoggedIn()) {
        return JSON.parse(localStorage.getItem("data")).student;
    }else{
        return undefined;
    }
};