import React from 'react'
//  import Container from 'react-bootstrap/Container';
//   import Nav from 'react-bootstrap/Nav';
//   import Navbar from 'react-bootstrap/Navbar';
//   import { FaRegCopyright } from 'react-icons/fa';
import '../Pages/User.css';


export const CusFooter = () => {
  // return (
  
  //       <>
  //       <div className='mt-3'>

  //       <Navbar bg="dark" variant="dark"  fixed='bottom' className='justify-content-center'>
        
        
  //         <Nav >
  //         <Nav.Link ><p ><FaRegCopyright/> QuickLearn 2022</p></Nav.Link>
  //         </Nav>
        
  //     </Navbar>
  //       </div>
        
  //       </>
  //   <div className="footer">
  //       <h3><FaRegCopyright/> Quicklearn 2022 </h3>
  //   </div>
   
    
  // )
  return(
    <section class="bg-dark" id='footer'>
       <div class="container">
         <div class="row">  
          <div class="col-sm-12">
            <h6 class="text-white text-center mb-3 mt-3">Copyright @ Loreal Ipsom Rights Reserved</h6>
            </div>  
         </div>
       </div>    
    </section>

)
}
