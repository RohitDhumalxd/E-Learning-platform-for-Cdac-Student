import React from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";
import { BsLinkedin  } from 'react-icons/bs';


const Home = () => {

  const navigate=useNavigate();

  const login=()=>{
    navigate('/login')
  }

  const signup=()=>{
    navigate('/signup')
  }
  return (
    <>
      {/* <div className="container">
      
            <div class="card bg-dark text-white  ">
              <img id="img" src="https://wallpaperaccess.com/full/1576448.jpg" alt="First slide"/>
              <div className="card-img-overlay mt-5">

              </div>
            </div>
          
       
      </div> */}
      <div class="card bg-dark text-white " data-ride="carousel">
        <img
          id="img"
          src="https://wallpaperaccess.com/full/1576448.jpg"
          alt="First slide"
        />
        <div class="card-img-overlay">
          <div className="container-fluid  mt-5">
            <div className="container-fluid my-5">
              <div class="row ">
                <div className="col-10"></div>
                <div className="col-1 ">
                  <h3>LogIn</h3>
                </div>
                <div className="col-1">
                  <h3>SignUp</h3>
                </div>
              </div>
              <div className="row mt-5">
                <div className="col-10"></div>
                <div className="col-1">
                  <button type="button" onClick={login} class="btn btn-primary btn-lg">
                    Login{" "}
                  </button>
                </div>
                <div className="col-1">
                  <button type="button" onClick={signup} class="btn btn-secondary btn-lg">
                    Signup{" "}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
       <section  class="p-5 bg-secondary">
      <div class="container">
        <h2 class="text-center text-white">Team Members</h2>
        
        <div class="row g-4">
          <div class="col-md-6 col-lg-4">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFOKkVJF6cENQSBcy3gpVHIS0y8dP-qeFlGVfm9MhbQpEQRT6l-JSoNeXdLEOK_KL28og&usqp=CAU"
                  class="rounded-circle mb-3"  width='200px'
                  alt=""
                />
                <h3 class="card-title mb-3">Rohit Dhumal</h3>
                <p class="card-text">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Assumenda accusamus nobis sed cupiditate iusto? Quibusdam.
                </p>
                
                <a href="https://linkedin.com/in/rohit-dhumal-11a406215" target="_blank" rel="noopener noreferrer"><h6><BsLinkedin size={28}/> </h6></a>
                
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="https://img.freepik.com/premium-vector/woman-profile-cartoon_18591-58480.jpg"
                  class="rounded-circle mb-3"  width='200px'
                  alt=""
                />
                <h3 class="card-title mb-3">Snehal Jadhav</h3>
                <p class="card-text">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Assumenda accusamus nobis sed cupiditate iusto? Quibusdam.
                </p>
                <a href="#Home" target="_blank" rel="noopener noreferrer"><h6><BsLinkedin size={28}/> </h6></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="https://img.freepik.com/premium-vector/man-profile-cartoon_18591-58482.jpg?w=2000"
                  class="rounded-circle mb-3" width='200px'
                  alt=""
                />
                <h3 class="card-title mb-3">Pranay Dodake</h3>
                <p class="card-text">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Assumenda accusamus nobis sed cupiditate iusto? Quibusdam.
                </p>
                <a href="https://linkedin.com/in/pranay-dodake-1aa7a2229" target="_blank" rel="noopener noreferrer"><h6><BsLinkedin size={28}/> </h6></a>
              </div>
            </div>
          </div>    
        </div>
      </div>
    </section>
    <section id="about" class="pb-5 bg-secondary">
      <div class="container">

        <div class="row ">
          <div class="col-md-6 col-lg-4">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="https://img.freepik.com/premium-vector/man-profile-cartoon_18591-58482.jpg?w=2000"
                  class="rounded-circle mb-3"  width='200px'
                  alt=""
                />
                <h3 class="card-title mb-3">Himanshu Saxena</h3>
                <p class="card-text">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Assumenda accusamus nobis sed cupiditate iusto? Quibusdam.
                </p>
                <a href="https://www.linkedin.com/in/himanshu-saxena-4125b2130?" target="_blank" rel="noopener noreferrer"><h6><BsLinkedin size={28}/> </h6></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="https://img.freepik.com/premium-vector/man-profile-cartoon_18591-58482.jpg?w=2000"
                  class="rounded-circle mb-3"  width='200px'
                  alt=""
                />
                <h3 class="card-title mb-3">Sumit Gorade</h3>
                <p class="card-text">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Assumenda accusamus nobis sed cupiditate iusto? Quibusdam.
                </p>
                <a href="#Home" target="_blank" rel="noopener noreferrer"><h6><BsLinkedin size={28}/> </h6></a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="card bg-light">
              <div class="card-body text-center">
                <img
                  src="https://img.freepik.com/premium-vector/man-profile-cartoon_18591-58482.jpg?w=2000"
                  class="rounded-circle mb-3"  width='200px'
                  alt=""
                />
                <h3 class="card-title mb-3">Durgesh Pandey</h3>
                <p class="card-text">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Assumenda accusamus nobis sed cupiditate iusto? Quibusdam.
                </p>
                 <a href="https://www.linkedin.com/in/devdnp" target="_blank" rel="noopener noreferrer"><h6><BsLinkedin size={28}/> </h6></a>
              </div>
            </div>
          </div>

          

          
        </div>
      </div>
    </section>
    <section class="p-5">
      
    </section>
      
    </>
  );
};
export default Home;
