import React from "react"
import './User.css'
export const AdvanceJava = () => {
    return (
      <div class="mb-5" >
      <div class="p-3 mb-2  text-dark">
        <h1 id='java'> Web based Java Programming</h1>
      </div>
  
     
  <div class="container ">
  <div className="card bg-dark text-white  mx-md-n8 ">
  <img src="https://cdn.pixabay.com/photo/2017/10/31/19/05/web-design-2906159_960_720.jpg" class="card-img img-fluid" alt="..."/>
  <div class="card-img-overlay mt-5">
      <h1 id='innerjava'>Advance Java</h1>
    <h3 class="card-title">Overview of Advance Java :</h3>
    <p class="card-text" > <b>

            Java is divided into two parts i.e. Core Java (J2SE) and Advanced Java (JEE).
            The core Java part covers the fundamentals (data types, functions, operators,
            loops, thread, exception handling, etc.) of the Java programming language. 
            It is used to develop general purpose applications. Whereas Advanced Java 
            covers the standard concepts such as database connectivity, networking, Servlet, 
            web-services, etc. In this section, we will discuss what is advance Java, its benefit, 
            uses, topics of advance Java, and the difference between core Java and advance Java.</b></p> <br />
           <b> It is a part of Java programming language. It is an advanced technology or advance version of 
            Java specially designed to develop web-based, network-centric or enterprise applications.
            It includes the concepts like Servlet, JSP, JDBC, Hibernate, Spring framework.
            It is a specialization in specific domain.</b>
          <hr></hr>
          <p> <b>
          Most of the applications developed using advance Java uses tow-tier architecture i.e. Client and Server.
            All the applications that runs on Server can be considered as advance Java applications.
          <div class="p-3 mb-2  text-Light">
            JEE (advance Java) provides libraries to understand the concept of Client-Server
            architecture for web- based applications.We can also work with web and application 
            servers such as Apache Tomcat and Glassfish Using these servers, we can understand the working of
            HTTP protocol. It cannot be done in core Java.
          </div>
          It provides a set of services, API and protocols, that provides the functionality 
          which is necessary for developing multi-tiered application, web-based application. 
          There is a number of advance Java frameworks like, Spring, Hibernate, Struts, that enables us to develop secure transaction-based web
          applications such as banking application, inventory management application.</b>
        </p>
    <hr></hr>
  </div>
  </div>
  </div>
  
  
  
  <hr></hr>
  
      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px" ,marginTop:"5px" }}>
            <img
              src="https://ashokitech.com/uploads/course/advanced-java-online-training.jpeg"
              class="img-fluid"
              alt="#"
            />
          </div>
          <div class="menu-text">
            <h2 class="main-title text-left">Web based advance java</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                <u>
                  {" "}
                  <h5> TOPIC </h5>{" "}
                </u>{" "}
              </p>
            </div>
  
            <div class="menu-content d-flex space-between">
              <p class="menu-name">Servlet and JSP (Server side programming in java)</p>
              <a
                href="https://youtube.com/playlist?list=PL0zysOflRCel5BSXoslpfDawe8FyyOSZb"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
                Servlet and JSP (Server side programming in java)
              </a>
              <p class="menu-name">Spring Framework Tutorial</p>
              <a
                href="https://youtube.com/playlist?list=PL0zysOflRCekeiERASkpi-crREVensZGS"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
                Spring Framework Tutorial
              </a>
              <p class="menu-name">Rest API using Spring Boot</p>
              <a
                href="https://youtube.com/playlist?list=PL0zysOflRCekYnhLjQGwpdJYzr38QXdhl"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
               Rest API using Spring Boot
              </a>
            </div>
            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                    </tr>
                  
                  
                    <tr>
                    <td>Edureka</td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://www.edureka.co/blog/advanced-java-tutorial"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>


                  <tr>
                    <td>Javatpoint</td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/what-is-advance-java#:~:text=It%20is%20a%20part%20of,a%20specialization%20in%20specific%20domain." className="btn btn-secondary btn-sm" 
                        target="_blank" rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>GeeksforGeeks</td>
                    <td>-----------------------</td>
  
                    <td>
  
                      <a
                        href="https://www.geeksforgeeks.org/difference-between-core-java-and-advanced-java/"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>W3schools</td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://www.w3schools.in/java"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>

  
                
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    )
  }