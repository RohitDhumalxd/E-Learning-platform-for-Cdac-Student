import React from "react";
import "./User.css";
export const Dsa = () => {
  return (
    <div class="mb-5">
      <div class="p-3 mb-2  text-dark">
        <h1 id="java">Data Structure & Algorithm</h1>
      </div>

      <div class="container ">
        <div className="card bg-dark text-white  mx-md-n8 ">
          <img
            src="https://images.pexels.com/photos/207700/pexels-photo-207700.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            class="card-img img-fluid"
            alt="..."
          />
          <div class="card-img-overlay mt-5">
            <h1 id="innerjava">Dsa</h1>
            <h3 class="card-title">Data Structures:</h3>
            <p class="card-text">
              {" "}
              <b>
                Data Structures are the programmatic way of storing data so that
                data can be used efficiently. Almost every enterprise
                application uses various types of data structures in one or the
                other way. This tutorial will give you a great understanding on
                Data Structures needed to understand the complexity of
                enterprise level applications and need of algorithms, and data
                structures.
              </b>
            </p>{" "}
            <br />
            <h4>Applications of Data Structure and Algorithms?</h4>
            Algorithm is a step-by-step procedure, which defines a set of
            instructions to be executed in a certain order to get the desired
            output. Algorithms are generally created independent of underlying
            languages, i.e. an algorithm can be implemented in more than one
            programming language. From the data structure point of view,
            following are some important categories of algorithms −<br />
            <ul class="list">
            <li><p><b>Search</b> &minus; Algorithm to search an item in a data structure.</p></li>
            <li><p><b>Sort</b> &minus; Algorithm to sort items in a certain order.</p></li>
            <li><p><b>Insert</b> &minus; Algorithm to insert item in a data structure.</p></li>
            <li><p><b>Update</b> &minus;  Algorithm to update an existing item in a data structure.</p></li>
            <li><p><b>Delete</b> &minus; Algorithm to delete an existing item from a data structure.</p></li>
            </ul>
            <hr></hr>
          </div>
        </div>
      </div>

      <hr></hr>

      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px", marginTop: "5px" }}>
            <img
              src="https://miro.medium.com/max/1024/1*9QRFQdpO2f59GsN2KsE9XA.png"
              class="img-fluid"
              alt="#"
            />
          </div>
          <div class="menu-text">
            <h2 class="main-title text-left">Data Structure</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                <u>
                  {" "}
                  <h5> TOPIC </h5>{" "}
                </u>{" "}
              </p>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">Complete Dsa Course Tutorial (Videos)</p>
              <a
                href="https://youtube.com/playlist?list=PLH9iLcrNpXtQYQiudzpZpGw0mptHc06Su"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer" className="btn btn-secondary btn-sm"
              >
                Complete Data structure and algorithm Tutorial (Videos) by ForMyScholars
              </a>
            </div>
            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                  </tr>
                  

                  <tr>
                    <td>Java-T-Point</td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/data-structure-structure"
                        className="btn btn-secondary btn-sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>


                  <tr>
                    <td>GeeksforGeeks</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.geeksforgeeks.org/data-structures/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>W3School</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.w3schools.in/data-structures/tutorials/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>TutorialPoint</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.tutorialspoint.com/data_structures_algorithms/index.htm"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
      <hr />
    </div>
  );
};
