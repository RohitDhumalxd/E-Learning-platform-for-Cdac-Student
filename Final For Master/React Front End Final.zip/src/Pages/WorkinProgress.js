import React from 'react'

export const WorkInProgress = () => {
  

    return (

    <div className='container-sm text-center'>
        {/* https://cdn.dribbble.com/users/1791559/screenshots/4465351/wip.gif */}
        
            <h1 id='work'>Work In Progress...</h1>
            <img src="https://cdn.dribbble.com/users/1791559/screenshots/4465351/wip.gif" alt="" id='workImg' height='500px'/>
           
    </div>
  )
}
