
 import { useEffect, useState } from 'react';

import Container from 'react-bootstrap/Container';
 import Nav from 'react-bootstrap/Nav';
 import Navbar from 'react-bootstrap/Navbar';
 import { FaUserCheck  } from 'react-icons/fa';
 
 import {
   Link, useNavigate
  } from "react-router-dom";
import { toast } from 'react-toastify';
import { doLogout, getCurrentUserDetails, isLoggedIn } from '../Auth';




const CusNavbar =()=>{

  const [login,setLogin]=useState(false)
  const [user,setUser]=useState(undefined)

  useEffect(()=>{

    setLogin(isLoggedIn())
    setUser(getCurrentUserDetails())

  },[login])

  const navigate= useNavigate();

  const logout=()=>{
    doLogout(()=>{
      // Logged out done token removed from the localStorage
      setLogin(false)
      toast.success("Logged Out Successfully !!!!!!!")
      navigate("/")
    })
  }

    return(
        
       <>
     
       <Navbar bg="dark" variant='dark' expand="lg" className='px-4' fixed='top'>
      <Container fluid>
      <Navbar.Brand as={Link} to='#'>
            <img
              alt=""
              src="https://img.icons8.com/doodle/48/000000/teaching.png"
              width="40"
              height="40"
              className="d-inline-block align-top"
            />{' '}
            QuickLearn
          </Navbar.Brand>
        {/* <Navbar.Brand as={Link} to='/' >QuickLearn</Navbar.Brand> */}
        {/* <img width="130px" height="70px"src="" alt='' style="position:relative;top:-10px"/> */}
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            {/* IF User is not logged in then Show Login And Signup Option */}
           {
            ! login &&(
              <>
               <Nav.Link as={Link} to="/">Home</Nav.Link>
              </>
            )
           }
           
           
           
          </Nav>
         
           <Nav>

          {/* IF user is logged in then Show Logout And User--> Email */}
            {
              login &&(
              <>
               
                <Nav.Link><FaUserCheck size={28}/></Nav.Link>
                <Nav.Link as={Link} to="/user/dashboard">{user.email}</Nav.Link>
                <Nav.Link onClick={logout}>Logout</Nav.Link>
              </>
              )
            }
          {/* IF User is not logged in then Show Login And Signup Option */}
            {
              ! login &&(
                <>
                <Nav.Link as={Link} to="/login">Login</Nav.Link>
                <Nav.Link as={Link} to="/signup">Signup</Nav.Link> 
                </>
              )
            }
           </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
      <div>

     
      </div>
      </>
     
  );
}
export default CusNavbar;
