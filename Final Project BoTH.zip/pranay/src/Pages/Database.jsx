import React from "react";
import "./User.css";
export const Database = () => {
  return (
    <div class="mb-5">
      <div class="p-3 mb-2  text-dark">
        <h1 id="java">Database Technologies</h1>
      </div>

      <div class="container ">
        <div className="card bg-dark text-white  mx-md-n8 ">
          <img
            src="https://st.depositphotos.com/1000423/1360/i/600/depositphotos_13601349-stock-photo-database-table.jpg"
            class="card-img img-fluid"
            alt="..."
          />
          <div class="card-img-overlay mt-5">
            <h1 id="innerjava">RDBMS</h1>
            <h3 class="card-title">MYSQL</h3>
            <p class="card-text">
              {" "}
              <b>
                The software used to store, manage, query, and retrieve data
                stored in a relational database is called a relational database
                management system (RDBMS). The RDBMS provides an interface
                between users and applications and the database, as well as
                administrative functions for managing data storage, access, and
                performance.
              </b>
            </p>{" "}
            <b>
            <br />
            Several factors can guide your decision when choosing among database
            types and relational database products. The RDBMS you choose will
            depend on your business needs. Ask yourself the following questions:{" "}
            <br />
            What are our data accuracy requirements? Will data storage and
            accuracy rely on business logic? Does our data have stringent
            requirements for accuracy (for example, financial data and
            government reports)? <br /> <br />
            Do we need scalability? What is the scale of the data to be managed,
            and what is its anticipated growth? Will the database model need to
            support mirrored database copies (as separate instances) for
            scalability? If so, can it maintain data consistency across those
            instances? <br />
            How important is concurrency? Will multiple users and applications
            need simultaneous data access? Does the database software support
            concurrency while protecting the data? What are our performance and
            reliability needs? Do we need a high-performance, high-reliability
            product? What are the requirements for query-response performance?
            What are the vendor’s commitments for service level agreements
            (SLAs) or unplanned downtime?
            </b>
            <hr></hr>
            <p>
              {" "}
              <b>
                A relational database is a type of database that stores and
                provides access to data points that are related to one another.
                Relational databases are based on the relational model, an
                intuitive, straightforward way of representing data in tables.
                In a relational database, each row in the table is a record with
                a unique ID called the key. The columns of the table hold
                attributes of the data, and each record usually has a value for
                each attribute, making it easy to establish the relationships
                among data points.
              </b>
            </p>
            <hr></hr>
          </div>
        </div>
      </div>

      <hr></hr>

      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px", marginTop: "5px" }}>
            <img
              src="https://s7280.pcdn.co/wp-content/uploads/2016/06/database-blue.png"
              class="img-fluid"
              alt="#"
            />
          </div>
          <div class="menu-text">
            <h2 class="main-title text-left">Database</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                <u>
                  {" "}
                  <h5> TOPIC </h5>{" "}
                </u>{" "}
              </p>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">Complete Database Course Tutorial (Videos)</p>
              <a
                href="https://youtube.com/playlist?list=PLxCzCOWd7aiFAN6I8CuViBuCdJgiOkT2Y"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
                
              >
                Complete DataBase (DBMS) (Videos) by Gate Smashers 
              </a>
            </div>
            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                  </tr>
                 

                  <tr>
                    <td>Java-T-Point</td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/dbms-tutorial"
                        className="btn btn-secondary btn-sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  

                  
                  <tr>
                    <td>GeeksforGeeks</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.geeksforgeeks.org/dbms/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>W3School</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.w3schools.com/sql/sql_ref_database.asp"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
      <hr />
    </div>
  );
};
