import React from "react";
import "./User.css";
export const MsDotNet = () => {
  return (
    <div class="mb-5">
      <div class="p-3 mb-2  text-dark">
        <h1 id="java">Microsoft .NET Framework </h1>
      </div>

      <div class="container ">
        <div className="card bg-dark text-white  mx-md-n8 ">
          <img
            src="https://cdn.pixabay.com/photo/2017/10/31/19/05/web-design-2906159_960_720.jpg"
            class="card-img img-fluid"
            alt="..."
          />
          <div class="card-img-overlay mt-5">
            <h1 id="innerjava">.NET Framework</h1>
            <h3 class="card-title">Ms.Net</h3>
            <p class="card-text">
              {" "}
              <b>
                The .NET Framework (pronounced as "dot net") is a proprietary
                software framework developed by Microsoft that runs primarily on
                Microsoft Windows. It was the predominant implementation of the
                Common Language Infrastructure (CLI) until being superseded by
                the cross-platform .NET project. It includes a large class
                library called Framework Class Library (FCL) and provides
                language interoperability (each language can use code written in
                other languages) across several programming languages. Programs
                written for .NET Framework execute in a software environment (in
                contrast to a hardware environment) named the Common Language
                Runtime (CLR). The CLR is an application virtual machine that
                provides services such as security, memory management, and
                exception handling. As such, computer code written using .NET
                Framework is called "managed code". FCL and CLR together
                constitute the .NET Framework.
              </b>
              <br />
              <br />
              <h2>.NET Core Overview</h2>
              <b>
                .NET Core is a new version of .NET Framework, which is a free,
                open-source, general-purpose development platform maintained by
                Microsoft. It is a cross-platform framework that runs on
                Windows, macOS, and Linux operating systems. <br /> <br />
                .NET Core Framework can be used to build different types of
                applications such as mobile, desktop, web, cloud, IoT, machine
                learning, microservices, game, etc. <br /> <br />
                .NET Core is written from scratch to make it modular,
                lightweight, fast, and cross-platform Framework. It includes the
                core features that are required to run a basic .NET Core app.
                Other features are provided as NuGet packages, which you can add
                it in your application as needed. In this way, the .NET Core
                application speed up the performance, reduce the memory
                footprint and becomes easy to maintain.
              </b>
            </p>
            <hr></hr>
          </div>
        </div>
      </div>

      <hr></hr>

      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px", marginTop: "5px" }}>
            <img
              src="https://www.webmynesystems.com/images/dotnet-services.png"
              class="img-fluid"
              alt="#"
            />
          </div>
          <div class="menu-text">
            <h2 class="main-title text-left">Concepts of .Net</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                <u>
                  {" "}
                  <h5> TOPIC </h5>{" "}
                </u>{" "}
              </p>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">Complete .Net FrameWork <br /> Course Tutorial (Videos)</p>
              <br /><br />
              <a
                href="https://youtube.com/playlist?list=PLVlQHNRLflP-jc5Fbhfdhzv52AWYq836j"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-secondary btn-sm"
              >
                Complete Dot Net Framework Tutorial (Videos) by Naresh i Technologies
              </a>
            </div>
            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                  </tr>
                  <tr>
                    <td>.NET documentation</td>

                    <td>----------------------- </td>
                    <td>
                      <a
                        href="https://learn.microsoft.com/en-us/dotnet/?WT.mc_id=dotnet-35129-website"
                        className="btn btn-secondary btn-sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>Java-T-Point</td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/net-framework"
                        className="btn btn-secondary btn-sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
        

                  <tr>
                    <td>GeeksforGeeks</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.geeksforgeeks.org/introduction-to-net-framework/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>W3School</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.w3schools.com/asp/webpages_intro.asp#gsc.tab=0&gsc.q=.net"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
      <hr />
    </div>
  );
};
