import React from "react";
import "./User.css";

export const Webtech = () => {
  return (
    <div class="mb-5">
      <div class="p-3 mb-2  text-dark">
        <h1 id="java">Web Programming Technologies</h1>
      </div>

      <div class="container ">
        <div className="card bg-dark text-white  mx-md-n8 ">
          <img
            src="https://d1uxiwmpc9j4yg.cloudfront.net/images/all/shutter_1642603130.webp"
            class="card-img img-fluid"
            alt="..."
          />
        </div>

        <hr></hr>

        <div class="p-3 mb-2 bg-dark text-white text-center">
          What is meant by general aptitude? 🧐🧐🧐
          <hr></hr>
          <div class="p-3 mb-2 bg-primary text-white">
            <p>
              It is an individual's innate, learned or acquired ability to
              perform specific tasks. It helps assess an individual's capacity
              to learn and understand, in general, regardless of any particular
              skill. General aptitude tests play a significant role at the time
              of recruitment.
            </p>
          </div>
          <ul class="list-group list-group-flush text-center">
            <li class="list-group-item  bg-primary text-white m-3 mb-2">
              {" "}
              Technologies
            </li>
            <li class="list-group-item">
              <p class="text-primary m-0">HTML (HyperText Markup Language)</p>
            </li>

            <div class="p-3 mb-2 bg-secondary text-white">
              <p>
                What is HTML used for?
                <br></br>
                Image result for html HTML (HyperText Markup Language) is the
                code that is used to structure a web page and its content. For
                example, content could be structured within a set of paragraphs,
                a list of bulleted points, or using images and data tables.
              </p>
            </div>

            <li class="list-group-item">
              <p class="text-danger m-0">CSS (Cascading Style Sheets)</p>
            </li>

            <div class="p-3 mb-2 bg-light text-dark">
              <p>
                CSS
                <br></br>
                CSS stands for Cascading Style Sheets. CSS describes how HTML
                elements are to be displayed on screen, paper, or in other
                media. CSS saves a lot of work. It can control the layout of
                multiple web pages all at once
              </p>
            </div>

            <li class="list-group-item">
              <p class="text-primary m-0"> JS (JavaScript)</p>
            </li>
            <div class="p-3 mb-2 bg-secondary text-white">
              <p>
                What do you mean by JS?
                <br></br>
                Image result for JS Javascript (JS) is a scripting languages,
                primarily used on the Web. It is used to enhance HTML pages and
                is commonly found embedded in HTML code. JavaScript is an
                interpreted language. Thus, it doesn't need to be compiled.
                JavaScript renders web pages in an interactive and dynamic
                fashion
              </p>
            </div>

            <li class="list-group-item">
              <p class="text-danger m-0">
                Ajax (Asynchronous JavaScript and XML)
              </p>
              <div class="p-3 mb-2 bg-light text-dark">
                <p>
                  AJAX stands for Asynchronous JavaScript And XML. In a
                  nutshell, it is the use of the XMLHttpRequest object to
                  communicate with servers. It can send and receive information
                  in various formats, including JSON, XML, HTML, and text files
                </p>
              </div>

              <li class="list-group-item">
                <p class="text-primary m-0">
                  {" "}
                  jQuery (JavaScript Framework Library - commonly used in Ajax
                  development))
                </p>
              </li>
              <div class="p-3 mb-2 bg-secondary text-white">
                <p>
                  What is jQuery is used for? jQuery is the most popular library
                  on the web today. It's a library of JavaScript functions that
                  make it easy for webpage developers to do common tasks-- like
                  manipulating the webpage, responding to user events, getting
                  data from their servers, building effects and animations, and
                  much more.
                </p>
              </div>

              <li class="list-group-item">
                <p class="text-primary m-0">Node. js (Node)</p>
              </li>
              <div class="p-3 mb-2 bg-light text-dark">
                <p>
                  Node. js is primarily used for non-blocking, event-driven
                  servers, due to its single-threaded nature. It's used for
                  traditional web sites and back-end API services, but was
                  designed with real-time, push-based architectures in mind.
                </p>
              </div>
              <li class="list-group-item">
                <p class="text-danger m-0">Express.js</p>{" "}
              </li>
              <div class="p-3 mb-2 bg-secondary text-white">
                <p>
                  What is ExpressJS used for? Express is a node js web
                  application framework that provides broad features for
                  building web and mobile applications. It is used to build a
                  single page, multipage, and hybrid web application. It's a
                  layer built on the top of the Node js that helps manage
                  servers and routes.
                </p>
              </div>

              <li class="list-group-item">
                <p class="text-primary m-0">React Js</p>
              </li>
              <div class="p-3 mb-2 bg-light text-dark">
                <p>
                  The React. js framework is an open-source JavaScript framework
                  and library developed by Facebook. It's used for building
                  interactive user interfaces and web applications quickly and
                  efficiently with significantly less code than you would with
                  vanilla JavaScript.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <hr></hr>

      <div></div>

      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px", marginTop: "5px" }}>
            <img
              src="https://www.shutterstock.com/image-vector/vector-collection-web-development-shield-600w-1757407325.jpg"
              class="img-fluid"
              alt="#"
            />

            <hr></hr>

            <img
              src="https://www.shutterstock.com/image-photo/react-js-inscription-against-laptop-600w-1853300929.jpg"
              class="img-fluid"
              alt="#"
            />

            <hr></hr>
            <img
              src="https://www.shutterstock.com/image-photo/express-inscription-against-laptop-code-600w-1903381375.jpg"
              class="img-fluid"
              alt="#"
            />
          </div>
          <div class="menu-text ">
            <h2 class="main-title text-center">Web Programming Technologies</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                <u>
                  <h5> Video Tutorial </h5>
                </u>
              </p>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">  HTML Tutorial (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=BsDoLVMnmZs"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
               HTML Tutorial For Beginners 
              </a>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name"> CSS Tutorials (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=w2z7BMr4MY0"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
                CSS Tutorial for Beginners in 2022 
              </a>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                JS (JavaScript) Tutorial (Videos)
              </p>
              <a
                href="https://www.youtube.com/watch?v=cvvwkgp4HBg&list=PLu0W_9lII9ajyk081To1Cbt2eI5913SsL"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
                 JS (JavaScript)
              </a>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name"> Ajax (Asynchronous JavaScript and XML) (Videos)</p>
              <a
                href="https://www.youtube.com/results?sp=mAEB&search_query=Ajax+"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
               Ajax (Asynchronous JavaScript and XML)
              </a>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">jQuery Tutorial (Videos)</p>
              <a
                href="https://www.youtube.com/results?sp=mAEB&search_query=Ajax+"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
              jQuery (JavaScript Framework Library - commonly used in Ajax development))
              </a>
            </div>


            <div class="menu-content d-flex space-between">
              <p class="menu-name">Node.js  Tutorial (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=TlB_eWDSMt4"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
              Node. js (Node)
              </a>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">Express.js tutorial (video)</p>
              <a
                href="https://www.youtube.com/watch?v=L72fhGm1tfE"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
             Express.js 
              </a>
            </div>


            <div class="menu-content d-flex space-between">
              <p class="menu-name">React Js tutorial (video)</p>
              <a
                href="https://www.youtube.com/watch?v=QFaFIcGhPoM&list=PLC3y8-rFHvwgg3vaYJgHGnModB54rxOk3"
                class="link-info"
                target="_blank"
                rel="noopener noreferrer"
              >
             React Js
              </a>
            </div>






            <hr></hr>

            <div class="embed-responsive embed-responsive-16by9" >
  <iframe  style={{width:"100%"}}class="embed-responsive-item" src="https://media.istockphoto.com/videos/programming-source-code-abstract-background-video-id1046965704" allowfullscreen></iframe>
</div>

<hr></hr>





            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                  </tr>
                  <tr>  
                    <td>
                      <p class="text-primary">W3School [HTML]</p>
                    </td>

                    <td>----------------------- </td>
                    <td>
                      <a
                        href="https://www.w3schools.com/html/"
                        className="btn btn-secondary btn-sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>
                      <p class="text-primary">Java-T-Point[ CSS ] </p>
                    </td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/css-tutorial"
                        className="btn btn-secondary btn-sm"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>
                      <p class="text-primary"> Mozila Box   [JavaScript]  </p>
                    </td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://developer.mozilla.org/en-US/docs/Web/JavaScript"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>
                      {" "}
                      <p class="text-primary"> Tutorials Point [ Ajax ] </p>
                    </td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.tutorialspoint.com/ajax/index.htm"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>
                      {" "}
                      <p class="text-primary">API doc jQuery [jQuery] </p>
                    </td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://api.jquery.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>
                      {" "}
                      <p class="text-primary"> Tutorials Teacher [Nodejs]</p>
                    </td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.tutorialsteacher.com/nodejs"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>
                      {" "}
                      <p class="text-primary">Mastering BackEnd [ExpressJS] </p>
                    </td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://masteringbackend.com/posts/expressjs-5-tutorial-the-ultimate-guide"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      {" "}
                      <p class="text-primary"> React.org [ react ] </p>
                    </td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://reactjs.org/tutorial/tutorial.html"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                 



       
                </thead>
              </table>
            </div>
            <br></br>
            <br></br>
            <br></br>
            <br></br>

 
          </div>
        </div>
      </div>
    </div>
  );
};
