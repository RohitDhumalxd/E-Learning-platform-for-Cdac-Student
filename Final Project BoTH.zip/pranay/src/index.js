import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';
import Base from './Components/Base';
import Home from './Components/Home';
import Login from './Components/Login';
import Signup from './Components/Signup';

import { BrowserRouter, Routes, Route} from "react-router-dom";
import { Userdashboard } from './Pages/Userdashboard';
import { PrivateRoute } from './Pages/PrivateRoute';
import { WorkInProgress } from './Pages/WorkinProgress';
import { Java } from './Pages/Java';
import { Dsa } from './Pages/Dsa.';
import { MsDotNet } from './Pages/MsDotNet';
import { Aptitude } from './Pages/Aptitude';
import { AdvanceJava } from './Pages/AdvanceJava';
import { OperatingSystem } from './Pages/OperatingSystem';
import { Webtech } from './Pages/Webtech';
import { Database, DataBase } from './Pages/Database';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
 
  <React.StrictMode>
    <ToastContainer position='bottom-center'/>
    <Base>
    </Base>
   
    
  </React.StrictMode>
  <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path='/login' element={<Login/>}/>
            <Route path='/signup' element={<Signup/>}/>
           

            {/* Private Routing here nesting of paths with help of Outlet*/}
            <Route path='/user' element={<PrivateRoute/>}>
                <Route path='dashboard' element={<Userdashboard/>}/>
                <Route path='work' element={<WorkInProgress/>}/>
                <Route path='java' element={<Java/>}/>
                <Route path='dsa' element={<Dsa/>}/>
                <Route path='dotnet' element={<MsDotNet/>}/>
                <Route path='aptitude' element={<Aptitude/>}/>
                <Route path='advanceJava' element={<AdvanceJava/>}/>
                <Route path='os' element={<OperatingSystem/>}/>
                <Route path='Webtech' element={<Webtech/>}/>
                <Route path='Database' element={<Database />}/>



            </Route>
        </Routes>
  </BrowserRouter>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
