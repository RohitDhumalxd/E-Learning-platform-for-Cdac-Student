const About=()=>{
    return(
       <div>

           <h1>This is About Page</h1>
           <p>this page contains info about developer</p>
       </div>


        
    );
};

export default About;
