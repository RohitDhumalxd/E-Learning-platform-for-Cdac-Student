 const Home= () =>{
    return(
        <div >
            <h1>This is Home page</h1>
            <p>Main page is web-Site</p>
        </div>
    );
 };
 export default Home;