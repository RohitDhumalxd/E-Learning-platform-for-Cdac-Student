const Signup= () =>{
    return(
        <div >
            <h1>This is Signup page</h1>
            <p>Welcome to log in page</p>
        </div>
    );
 };
 export default Signup;