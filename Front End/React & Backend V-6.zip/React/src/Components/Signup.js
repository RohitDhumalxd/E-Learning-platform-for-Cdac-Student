import React, {  useState } from 'react'
import { Card ,Container,CardHeader,CardBody ,Form,FormGroup,Label,Input,Button,Row,Col} from 'reactstrap';
import { signup } from '../Services/student-service';
import { toast } from 'react-toastify';

 const Signup = () => {

    const [data,setData] =useState({
        name:'',
        email:'',
        password:'',
        mobileNumber:'',
        security_question:'',
        security_answer:''
    });


    // const [error,setError]=useState({
    //     errors:{},
    //     isError:false
    // })

    // useEffect(()=>{
    //     console.log(data);
    // },[data]) 

    // HandleChange is used for getting data from input

    const handleChange=(event,property)=>{
      //  console.log("Name Changed");
      //  console.log(event.target.value);
      // Dynamic setting the Values
        setData({...data,[property]:event.target.value})
     
    }

    // To Reset Data when reset button is Clicked
    const resetData=()=>{
        setData({
            name:'',
            email:'',
            password:'',
            mobileNumber:'',
            security_question:'',
            security_answer:''
        })
    }

    // Submitting the Form
    const submitForm=(event)=>{
        event.preventDefault()
        console.log(data);
        // Data Validation
      

        // Call server api for sending data
        // takeing data from server and printing response on console
        signup(data).then((resp)=>{
            console.log(resp);
            console.log("Success Log");
            toast.success("Student is Resister successfully !!!")
           
            setData({
                name:'',
                email:'',
                password:'',
                mobileNumber:'',
                security_question:'',
                security_answer:''
            })
        })
        
    }
  return (
    <Container>
        {/* mt-5 margin from top side  !!!! size : 6 means Taking only 6 grid with offset of 3 both side */}
      <Row className='mt-5'>

            {JSON.stringify(data)}
            <Col sm={{size:6,offset:3}}>

            <Card>
            <CardHeader>
                <h3>Fill Information to Register !!</h3>
            </CardHeader>
            <CardBody>

                    {/* Creating Form here  */}
                    <Form onSubmit={submitForm}>
                        {/* Name Field */}
                        <FormGroup>
                            <Label for='name'>Enter Name</Label>
                            <Input type='text' 
                            placeholder=' Enter Here'
                            id='name'
                            onChange={(e)=>handleChange(e,'name')}
                            // to recheck or Confirm value 2 way data Binding
                            value={data.name}
                            required
                            />
                        </FormGroup>

                        {/* Email Field */}
                        <FormGroup>
                            <Label for='email'>Enter email</Label>
                            <Input type='email' 
                            placeholder=' Enter Here'
                            id='email'
                            onChange={(e)=>handleChange(e,'email')}
                            value={data.email}
                            required
                            />
                        </FormGroup>

                        {/* Password Field */}
                        <FormGroup>
                            <Label for='password'>Enter Password</Label>
                            <Input type='password' 
                            placeholder='eg. Abcd@1234'
                            id='password'
                            onChange={(e)=>handleChange(e,'password')}
                            value={data.password}
                            required
                            />
                        </FormGroup>

                        <FormGroup>
                            <Label for='mobileNumber'>Enter Mobile-Number</Label>
                            <Input type='tel' 
                            placeholder=' Enter Here'
                            id='mobileNumber'
                            onChange={(e)=>handleChange(e,'mobileNumber')}
                            value={data.mobileNumber}
                            required
                            minLength={10}
                            />
                        </FormGroup>

                            {/* Security Question Field */}
                            <FormGroup>
                            <Label for='security_question'>Enter Security Question</Label>
                            <Input type='text' 
                            placeholder=' Enter Here'
                            id='security_question'
                            onChange={(e)=>handleChange(e,'security_question')}
                            value={data.security_question}
                            required
                            />
                        </FormGroup>

                            {/* Security Answer Field */}
                            <FormGroup>
                            <Label for='security_answer'>Enter Security Answer</Label>
                            <Input type='text' 
                            placeholder=' Enter Here'
                            id='security_answer'
                            onChange={(e)=>handleChange(e,'security_answer')}
                            value={data.security_answer}
                            required
                            />
                        </FormGroup>

                        <Container className='text-center'>
                            <Button color='success'>Register</Button>
                            <Button color='danger' onClick={resetData} type='reset' className='ms-3'>Reset</Button>
                        </Container>

                    </Form>
            </CardBody>
      </Card>
            </Col>
      </Row>
      
    </Container>
    
  )
}

export default Signup;