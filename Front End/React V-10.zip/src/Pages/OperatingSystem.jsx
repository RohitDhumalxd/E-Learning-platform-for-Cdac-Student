import React from "react"
import './User.css'
export const OperatingSystem = () => {
    return (
      <div class="mb-5" >
      <div class="p-3 mb-2  text-dark">
        <h1 id='java'> Operating System</h1>
      </div>
  
     
  <div class="container ">
  <div className="card bg-dark text-white  mx-md-n8 ">
  <img src="https://cdn.pixabay.com/photo/2017/10/31/19/05/web-design-2906159_960_720.jpg" class="card-img img-fluid" alt="..."/>
  <div class="card-img-overlay mt-5">
      <h1 id='innerjava'>Operating System</h1>
    <h3 class="card-title">Overview of Operating System :</h3>
    <p class="card-text" > <b>

            An Operating System is a System Software (i.e. collection of programs) which acts as an 
            interface between user and hardware.Operating system is also called as a resource allocator,
            control program and resource manager. The purpose of an operating system is to provide an environment
            in which a user can execute programs conveniently and efficiently. </b></p> <br />
           <b> Examples of Operating System are – 

            Windows (GUI based, PC)
            GNU/Linux (Personal, Workstations, ISP, File and print server, Three-tier client/Server)
            macOS (Macintosh), used for Apple’s personal computers and workstations (MacBook, iMac).
            Android (Google’s Operating System for smartphones/tablets/smartwatches)
            iOS (Apple’s OS for iPhone, iPad, and iPod Touch)</b>
          <hr></hr>
          <p> <b>
          The process operating system as User Interface: User , System and application programs ,
          Operating system and Hardware
          <div class="p-3 mb-2  text-Light">
          The kernel is the central component of a computer operating systems. The only job performed by the kernel is to manage the communication between the software and the hardware
          Two most popular kernels are Monolithic and MicroKernels.
          Process, Device, File, I/O, Secondary-Storage, Memory management are various functions of an Operating System
          </div>
          If any issue occurs in OS, you may lose all the contents which have been stored in your system.
          Operating system’s software is quite expensive for small size organization which adds burden on them. Example Windows
          It is never entirely secure as a threat can occur at any time</b>
        </p>
    <hr></hr>
  </div>
  </div>
  </div>
  
  
  
  <hr></hr>
  
      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px" ,marginTop:"5px" }}>
            <img
              src="https://www.freecodecamp.org/news/content/images/2021/08/uide-to-writting-a-good-readme-file--6-.png"
              class="img-fluid"
              alt="#"
            />
          </div>
          <div class="menu-text">
            <h2 class="main-title text-left">Operating System</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                <u>
                  {" "}
                  <h5> TOPIC </h5>{" "}
                </u>{" "}
              </p>
            </div>
  
            <div class="menu-content d-flex space-between">
              <p class="menu-name">Operating System (Complete Playlist)</p>
              <a
                href="https://youtube.com/playlist?list=PLxCzCOWd7aiGz9donHRrE9I3Mwn6XdP8p"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
                Operating System (Complete Playlist)
              </a>
             
            </div>
            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                    </tr>
                  
                  
                    <tr>
                    <td>Tutorialspoint</td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://www.tutorialspoint.com/operating_system/os_overview.htm"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>


                  <tr>
                    <td>Javatpoint</td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/os-tutorial" className="btn btn-secondary btn-sm" 
                        target="_blank" rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>GeeksforGeeks</td>
                    <td>-----------------------</td>
  
                    <td>
  
                      <a
                        href="https://www.geeksforgeeks.org/introduction-of-operating-system-set-1/"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>Guru99</td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://www.guru99.com/operating-system-tutorial.html"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>

  
                
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    )
  }