import React from 'react'
import { useNavigate } from 'react-router-dom';
 import './User.css';
export const Userdashboard = () => {

  const navigate=useNavigate();

  const Work=()=>{
    navigate('/user/work')
  }

  const java=()=>{
    navigate('/user/java')
  }

  const Dsa=()=>{
    navigate('/user/dsa')
  }

  const Dotnet=()=>{
    navigate('/user/dotnet')
  }

  const Aptitued=()=>{
    navigate('/user/aptitude')
  }
  const AdvanceJava=()=>{
    navigate('/user/advanceJava')
  }
  const OperatingSystem=()=>{
    navigate('/user/os')
  }


  return (
   <>
   <h1 id='user' >Modules..</h1>
    <section className="p-3" >
                <div className="container">
                  <div className="row text-center g-3">
                    {/* This is For Java */}
                    <div className="col-md">
                      <div className="card text-dark"  id='c1'>
                        <div className="card-body text-center">
                          <img className="card-img-top"
                          src="https://liongueststudios.com/wp-content/uploads/2021/01/Object-Oriented-Programming-concepts-in-java-lionguest-studios.png"
                            alt='null' width="100%"
                            height="200px"/>
                          <h3 className="card-title mb-3">Java OOP (Object-Oriented Programming)</h3>
                          <p className="card-text">
                          Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.
                          </p>
                          <button onClick={java} className="btn btn-primary ">Read More</button>
                        </div>
                      </div>
                    </div>

                    {/* This is For OS */}
                    <div className="col-md">
                      <div className="card text-dark" id='c2'>
                        <div className="card-body text-center">
                          
                          <img
                          className="card-img-top"
                          src="https://media.istockphoto.com/photos/operating-system-word-cloud-picture-id514403369?s=612x612"
                          alt="" width="100%" height="230px"
                        />
                          <h3 className="card-title mb-3">Operating System</h3>
                          <p className="card-text">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                            Iure, quas quidem possimus dolorum esse eligendi?
                          </p>
                          <button onClick={OperatingSystem} className="btn btn-dark ">Read More</button>
                          
                        </div>
                      </div>
                    </div>

                    {/* This is For Data Base */}
                    <div className="col-md">
                      <div className="card bg-info text-dark" id='c3'>
                        <div className="card-body text-center">
                          
                          <img
                          className="card-img-top"
                          src="https://loiane.com/assets/images/2019/mysql-oracle-cloud.jpg"
                          alt="" width="100%" height="230px"
                        />
                          <h3 className="card-title mb-3">DataBase</h3>
                          <p className="card-text">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                            Iure, quas quidem possimus dolorum esse eligendi?
                          </p>
                          <button  onClick={Work} className="btn btn-primary ">Read More</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
              </section>
              <hr />

              <section className="p-3" >
                <div className="container">
                  <div className="row text-center g-3">
                    {/* This is For DSA */}
                    <div className="col-md">
                      <div className="card bg-info text-dark" id='c4' >
                        <div className="card-body text-center">
                          <img className="card-img-top"
                          src="https://w10.naukri.com/mailers/2022/naukri-learning/what-is/What-is-Data-Structures-and-Algorithms.jpg"
                            alt='null' width="100%" height="230px"/>
                          <h3 className="card-title mb-3">Data Structure</h3>
                          <p className="card-text">
                          A data structure is a storage that is used to store and organize data. It is a way of arranging data on a computer so that it can be accessed and updated efficiently.
                          </p>
                          <button  onClick={Dsa} className="btn btn-primary ">Read More</button>
                        </div>
                      </div>
                    </div>

                    {/* This is For Web Technologies */}
                    <div className="col-md">
                      <div className="card bg-secondary text-light" id='c5'>
                        <div className="card-body text-center">
                          
                          <img
                          className="card-img-top"
                          src="https://www.sharda.ac.in/blog/wp-content/uploads/2020/10/Latest-technologies-for-web-development2.jpg"
                          alt="" width="100%" height="230px"
                        />
                          <h3 className="card-title mb-3">Web technologies</h3>
                          <p className="card-text">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                            Iure, quas quidem possimus dolorum esse eligendi?
                          </p>
                          <button onClick={Work}  className="btn btn-dark ">Read More</button>
                          
                        </div>
                      </div>
                    </div>

                    {/* This is For ADV */}
                    <div className="col-md">
                      <div className="card bg-dark text-light" id='c6'>
                        <div className="card-body text-center">
                          
                          <img
                          className="card-img-top"
                          src="https://ashokitech.com/uploads/course/advanced-java-online-training.jpeg"
                          alt="" width="100%" height="230px"
                        />
                          <h3 className="card-title mb-3">Advanced Java</h3>
                          <p className="card-text">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                            Iure, quas quidem possimus dolorum esse eligendi?
                          </p>
                          
                     
                          <button  onClick={AdvanceJava} className="btn btn-primary ">Read More</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>  
              </section>
                <hr />
              <section className="p-3" >
                <div className="container">
                  <div className="row text-center g-3">

                    {/* This is For MS .NET */}
                    <div className="col-md">
                      <div className="card bg-dark text-light" id='c7' >
                        <div className="card-body text-center">
                          <img className="card-img-top"
                          src="https://www.secret-source.eu/wp-content/uploads/2017/11/microsoft-net-logo.jpg"
                            alt='null' width="100%" height="230px"/>
                          <h3 className="card-title mb-3">Microsoft Dot Net</h3>
                          <p className="card-text">
                          The .NET Framework is a proprietary software framework developed by Microsoft that runs primarily on Microsoft Windows. It was the predominant implementation of the Common Language Infrastructure until being superseded by the cross-platform.
                          </p>
                          <button  onClick={Dotnet} className="btn btn-primary ">Read More</button>
                        </div>
                      </div>
                    </div>

                    {/* This is For Software Development Methodology */}
                    <div className="col-md">
                      <div className="card bg-secondary text-light" id='c8'>
                        <div className="card-body text-center">
                          
                          <img
                          className="card-img-top"
                          src="https://www.laneways.agency/wp-content/uploads/2020/09/What-are-Software-Development-Methodologies-Laneways.Agency.jpg"
                          alt="" width="100%" height="260px"
                        />
                          <h3 className="card-title mb-3">Software Development Methodology</h3>
                          <p className="card-text">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                            Iure, quas quidem possimus dolorum esse eligendi?
                          </p>
                          <button onClick={Work}  className="btn btn-dark ">Read More</button>
                          
                        </div>
                      </div>
                    </div>

                    {/* This is For Aptitude */}
                    <div className="col-md">
                      <div className="card bg-info text-dark" id='c8'>
                        <div className="card-body text-center">
                          
                          <img
                          className="card-img-top"
                          src="http://www.outreacheducationinitiative.org/wp-content/uploads/2018/02/professional-clipart-professional-development-14-300x300.jpg"
                          alt="" width="100%" height="230px"
                        />
                          <h3 className="card-title mb-3">Aptitude</h3>
                          <p className="card-text">
                          An aptitude is a component of a competence to do a certain kind of work at a certain level. Outstanding aptitude can be considered "talent". Aptitude is inborn potential to perform certain kinds of activities, whether physical or mental, and whether developed or undeveloped
                          </p>
                          <button  onClick={Aptitued} className="btn btn-primary ">Read More</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
              </section>
              <hr />
              <hr />
              
   </>
  )
}
