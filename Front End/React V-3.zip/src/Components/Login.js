import React from 'react'
import { Card ,Container,CardHeader,CardBody ,Form,FormGroup,Label,Input,Button,Row,Col} from 'reactstrap';
 const Login = () => {
  return (
   <Container>
    <Row className='mt-5'>
      <Col sm={{size:6,offset:3}}>
          <Card>
              <CardHeader>
               <h3> Login Here !!</h3>
              </CardHeader>

              <CardBody>
                <Form>
                   {/* Email Field */}
                   <FormGroup>
                            <Label for='email'>Enter email</Label>
                            <Input type='email' 
                            placeholder=' Enter Here'
                            id='email'/>
                        </FormGroup>

                        {/* Password Field */}
                        <FormGroup>
                            <Label for='password'>Enter Password</Label>
                            <Input type='password' 
                            placeholder=' Enter Here'
                            id='password'/>
                        </FormGroup>
                        <Container className='text-center'>
                            <Button color='success'>Login</Button>
                            <Button color='danger' type='reset' className='ms-3'>Clear</Button>
                        </Container>
                </Form>
              </CardBody>
          </Card>
      </Col>
    </Row>
   </Container>
  )
}
export default Login;