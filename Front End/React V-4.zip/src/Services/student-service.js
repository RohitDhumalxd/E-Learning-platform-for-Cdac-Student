import { myAxios } from "./helper";

//for Signup we are using POST  ********* PROMISE
export const signup=(user)=>{
    //we are takeing result or response in Callback function
    return myAxios.post('/api/v1/auth/register',user).then((response)=> response.data());
  // return(fetch('http://localhost:8080/api/v1/auth/register', {
  //   method: 'POST',
  //   crossDomain: true,
  //   body: JSON.stringify(user),
  //   headers: {
      
  //     'Content-Type': 'application/json',
  //     'Access-Control-Allow-Origin': 'http://localhost:8080'
  //   }
  // }).then((response) => response.json())
  //   .then((data) => {
  //     console.log('Success:', data);
  //   })
  //   .catch((error) => {
  //     console.error('Error:', error);
  //   }));
};

