import { CusFooter } from "./Footer";
import CusNavbar from "./Navbar";

const Base=({title="Welcome to our website",children})=>{

    // This master page which contains Header and Footer
    return(
        <div className="container-fluid p-0 m-0">
            <CusNavbar/>

            {children}

           <CusFooter/>
        </div>
    );
};
export default Base;