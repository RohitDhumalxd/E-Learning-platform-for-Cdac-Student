import React from 'react'
 import Container from 'react-bootstrap/Container';
  import Nav from 'react-bootstrap/Nav';
  import Navbar from 'react-bootstrap/Navbar';
import '../Pages/User.css'
import { FaRegCopyright } from 'react-icons/fa';

export const CusFooter = () => {
  return (
  
      //   <>
      //   <div className='mt-3'  style={{marginbottom:0}}>

      //   <Navbar bg="dark" variant="dark"  fixed='bottom' className='justify-content-center'>
        
        
      //     <Nav >
      //     <Nav.Link ><p ><FaRegCopyright/> QuickLearn 2022</p></Nav.Link>
      //     </Nav>
        
      // </Navbar>
      //   </div>
        
      //   </>
    // <div className="footer">
    //     <h3><FaRegCopyright/> Quicklearn 2022 </h3>
    // </div>
    <>
    </>
    
  )
}
