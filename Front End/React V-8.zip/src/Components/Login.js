import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Card ,Container,CardHeader,CardBody ,Form,FormGroup,Label,Input,Button,Row,Col} from 'reactstrap';
import { doLogin } from '../Auth';
import { loginUser } from '../Services/student-service';
 const Login = () => {

  const [loginDetail,setLoginDetail]=useState({
    username:'',
    password:''
  })

  const handleChange=(event,field)=>{
    let actualValue=event.target.value
    setLoginDetail({
        ...loginDetail,
        [field]:actualValue
    })
  }
  

  const navigate=useNavigate();

 
  const handleFormSubmit=(event)=>{
    event.preventDefault();
    console.log(loginDetail);
    if (loginDetail.username === '') {
      toast.error("Username is Required !!")
      return;
    }
    if (loginDetail.password === '') {
      toast.error("Password is Required !!")
      return;
    }
  // Submitting data to server to generate token    
    loginUser(loginDetail).then((data)=>{
      console.log("User Login");
      console.log(data);

      // TO save data/JWT-Token to local storage
      doLogin(data,()=>{
        console.log('Login details is saved to local Storage');
        // Redirect to UserDashboard page
        navigate("/user/dashboard")
      })


      toast.success("Login Successfully")
    }).catch(error=>{
      console.log(error);
      if (error.response.status === 400 || error.response.status === 404) {
        toast.error(error.response.data.message)
      }else{
        toast.error("Something Went Wrong  on server!!")
      }
      
    })
  }

  const handleReset=()=>{
    setLoginDetail({
      username:'',
      password:''
    })
  }

  return (
   <Container className='mt-3'>
    <Row className='mt-5'>
      <Col sm={{size:6,offset:3}}>
          <Card>
              <CardHeader>
               <h3> Login Here !!</h3>
              </CardHeader>

              <CardBody>
                <Form onSubmit={handleFormSubmit}>
                   {/* Email Field */}
                   <FormGroup>
                            <Label for='email'>Enter email</Label>
                            <Input type='email' 
                            placeholder=' Enter Here'
                            id='email'
                            value={loginDetail.username}
                            onChange={(e)=> handleChange(e,'username')}
                            />
                        </FormGroup>

                        {/* Password Field */}
                        <FormGroup>
                            <Label for='password'>Enter Password</Label>
                            <Input type='password' 
                            placeholder=' Enter Here'
                            id='password'
                            value={loginDetail.password}
                            onChange={(e)=> handleChange(e,'password')}
                            />
                        </FormGroup>
                        <Container className='text-center'>
                            <Button color='success'>Login</Button>
                            <Button color='danger' onClick={handleReset} type='reset' className='ms-3'>Clear</Button>
                        </Container>
                </Form>
              </CardBody>
          </Card>
      </Col>
    </Row>
   </Container>
  )
}
export default Login;