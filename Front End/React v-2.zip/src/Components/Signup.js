import React from 'react'
import { Card ,Container,CardHeader,CardBody ,Form,FormGroup,Label,Input,Button,Row,Col} from 'reactstrap';

 const Signup = () => {
  return (
    <Container>
        {/* mt-5 margin from top side  !!!! size : 6 means Taking only 6 grid with offset of 3 both side */}
      <Row className='mt-5'>
            <Col sm={{size:6,offset:3}}>

            <Card>
            <CardHeader>
                <h3>Fill Information to Register !!</h3>
            </CardHeader>
            <CardBody>
                    {/* Creating Form here  */}
                    <Form>
                        {/* Name Field */}
                        <FormGroup>
                            <Label for='name'>Enter Name</Label>
                            <Input type='text' 
                            placeholder=' Enter Here'
                            id='name'/>
                        </FormGroup>

                        {/* Email Field */}
                        <FormGroup>
                            <Label for='email'>Enter email</Label>
                            <Input type='email' 
                            placeholder=' Enter Here'
                            id='email'/>
                        </FormGroup>

                        {/* Password Field */}
                        <FormGroup>
                            <Label for='password'>Enter Password</Label>
                            <Input type='password' 
                            placeholder=' Enter Here'
                            id='password'/>
                        </FormGroup>

                            {/* Security Question Field */}
                            <FormGroup>
                            <Label for='security_question'>Enter Security Question</Label>
                            <Input type='text' 
                            placeholder=' Enter Here'
                            id='security_question'/>
                        </FormGroup>

                            {/* Security Answer Field */}
                            <FormGroup>
                            <Label for='security_answer'>Enter Security Answer</Label>
                            <Input type='text' 
                            placeholder=' Enter Here'
                            id='security_answer'/>
                        </FormGroup>
                        <Container className='text-center'>
                            <Button color='success'>Register</Button>
                            <Button color='danger' className='ms-3'>Reset</Button>
                        </Container>
                    </Form>
            </CardBody>
      </Card>
            </Col>
      </Row>
      
    </Container>
    
  )
}

export default Signup;