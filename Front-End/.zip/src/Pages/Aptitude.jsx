import React from 'react'
import './User.css';


export const Aptitude = () => {
    return (
      <div class="mb-5" >
      <div class="p-3 mb-2  text-dark">
        <h1 id='java'> General Aptitude</h1>
      </div>
  
     
  <div class="container ">
  <div className="card bg-dark text-white  mx-md-n8 ">
  <img src="https://leverageedublog.s3.ap-south-1.amazonaws.com/blog/wp-content/uploads/2020/04/06203625/General-Aptitude.jpg" class="card-img img-fluid" alt="..."/>
  </div>
  <hr></hr>
  <div class="p-3 mb-2 bg-dark text-white">
  What is meant by general aptitude?
  <hr></hr>
  <div class="p-3 mb-2 bg-primary text-white">
    <p>It is an individual's innate, learned or acquired ability to perform specific tasks. It helps assess an individual's capacity to learn and understand, in general, regardless of any particular skill. General aptitude tests play a significant role at the time of recruitment.</p>
  </div>

  <ul class="list-group list-group-flush text-center">
  <li class="list-group-item  bg-dark text-white">What are the types of aptitude?</li>
  <li class="list-group-item">Logical aptitude</li>
  <li class="list-group-item">Spatial aptitude.</li>
  <li class="list-group-item">Organisational aptitude.</li>
  <li class="list-group-item">Physical aptitude.</li>
  <li class="list-group-item"> Mechanical aptitude.</li>
  <li class="list-group-item">Science, technology, engineering and math (STEM) aptitude. </li>
  <li class="list-group-item"> Linguistic aptitude.</li>
</ul>

  </div>
  </div>
  
  <hr></hr>

        <div></div>








  
      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px" ,marginTop:"5px" }}>
            <img
              src="https://www.shutterstock.com/image-vector/inspiration-thinking-concept-light-bulb-600w-644367028.jpg"
              class="img-fluid"
              alt="#"
            />

            

            <hr></hr>
               <img
              src="https://www.shutterstock.com/image-vector/light-bulb-inside-human-head-600w-1571643964.jpg"
              class="img-fluid"
              alt="#"
            />

            
<hr></hr>
               <img
              src="https://www.shutterstock.com/image-vector/example-aptitude-test-tool-determine-600w-1972707398.jpg"
              class="img-fluid"
              alt="#"
            />


          </div>
          <div class="menu-text ">
            <h2 class="main-title text-center">General Aptitude</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                
                <u>  
                <h5> Video Tutorial </h5>
                </u>
              </p>
            </div>
  
            <div class="menu-content d-flex space-between">
              <p class="menu-name">     Quantitative Aptitude Tutorials (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=tnc9ojITRg4&list=PLpyc33gOcbVA4qXMoQ5vmhefTruk5t9lt"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
               Quantitative Aptitude Tutorials 
              </a>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">      Logical Reasoning Tutorials (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=x0WkptLF6oE&list=PLpyc33gOcbVADMKqylI__O_O_RMeHTyNK"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
               Logical Reasoning Tutorials
              </a>
            </div>


            <div class="menu-content d-flex space-between">
              <p class="menu-name">      Physical Science General Aptitude (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=lcadWCfGaNI"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
              Physical Science General Aptitude Question
              </a>
            </div>



            <div class="menu-content d-flex space-between">
              <p class="menu-name">     Mechanical  Aptitude (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=jzNxXm5twx4"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
              Speed, Distance & Time
              </a>
            </div>




            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                  </tr>
                  <tr>
                    <td><p class="text-primary">India Bix</p></td>
  
                    <td>----------------------- </td>
                    <td>
                    <a href="https://www.indiabix.com/aptitude/questions-and-answers/" className="btn btn-secondary btn-sm"   target='_blank' rel="noopener noreferrer">Click Here</a>
                     
                    </td>
                  </tr>
  
                  <tr>
                    <td><p class="text-primary">Java-T-Point </p></td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/aptitude/quantitative" className="btn btn-secondary btn-sm" 
                        target="_blank" rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td><p class="text-primary"> Ambition Box </p></td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://www.ambitionbox.com/topics/aptitude/questions-and-answers"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td> <p class="text-primary">  TestBook </p></td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://testbook.com/aptitude-questions"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>   <p class="text-primary">FreshersNow  </p></td>
                    <td>-----------------------</td>
  
                    <td>
  
                      <a
                        href="https://www.freshersnow.com/aptitude-questions-answers-solutions/"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>   <p class="text-primary"> Sanfoundary </p></td>
                    <td>-----------------------</td>
  
                    <td>
                      <a
                        href="https://www.sanfoundry.com/mathematics-aptitude-test/"
                        target="_blank"  rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>




                  <tr>
                    <td>   <p class="text-primary"> CareerRide </p></td>
                    <td>-----------------------</td>
  
                    <td>
                      <a
                        href="https://www.careerride.com/online-aptitude-test.aspx"
                        target="_blank"  rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>   <p class="text-primary"> StuDocu </p></td>
                    <td>-----------------------</td>
  
                    <td>
                      <a
                        href="https://www.studocu.com/row/document/government-college-university-faisalabad/multivariable-calculus-mcqs/engineering-mathematics-aptitude-test-sanfoundry/13165655"
                        target="_blank"  rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>   <p class="text-primary"> Numerical Aptitude Test </p></td>
                    <td>-----------------------</td>
  
                    <td>
                      <a
                        href="https://www.aptitude-test.com/numerical-aptitude.html"
                        target="_blank"  rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>   <p class="text-primary"> Topper.com </p></td>
                    <td>-----------------------</td>
  
                    <td>
                      <a
                        href="https://www.toppr.com/guides/quantitative-aptitude/"
                        target="_blank"  rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>   <p class="text-primary"> PrepInsta </p></td>
                    <td>-----------------------</td>
  
                    <td>
                      <a
                        href="https://prepinsta.com/infosys-aptitude-questions/"
                        target="_blank"  rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>

                </thead>
              </table>


  
            </div>
            <br></br>
            <br></br>
            <br></br>
            <br></br>

            
            
            <img src="https://www.assessmentday.co.uk/logic/free/LogicalReasoningTest1/images/Q3.gif" class="card-img img-fluid" alt="..."/>
            
          </div>
        </div>
      </div>
    </div>
    )
  }