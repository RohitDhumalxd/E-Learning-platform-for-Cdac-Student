import React from "react";

const Java = () => {
  return (
    <div class="mb-5" >
      <div class="p-3 mb-2 bg-dark text-white">
        <h1 style={{ textAlign: "center" }}> Object Oriented Programming (OOPs)</h1>
      </div>

     
  

     
<div class="card bg-dark text-white  mx-md-n8 ">
  <img src="https://c4.wallpaperflare.com/wallpaper/837/636/972/programming-web-development-code-wallpaper-preview.jpg" class="card-img img-fluid" alt="..."/>
  <div class="card-img-overlay">
    <h3 class="card-title">HistoryAbout Java :</h3>
    <p class="card-text" > <b>Java’s history is very interesting. It is a
          programming language created in 1991. James Gosling, Mike Sheridan,
          and Patrick Naughton, a team of Sun engineers known as the Green team
          initiated the Java language in 1991. Sun Microsystems released its
          first public implementation in 1996 as Java 1.0. It provides no-cost
          -run-times on popular platforms. Java1.0 compiler was re-written in
          Java by Arthur Van Hoff to strictly comply with its specifications.
          With the arrival of Java 2, new versions had multiple configurations
          built for different types of platforms.</b></p> <br />
          In 1997, Sun Microsystems approached the ISO standards body and later
          formalized Java, but it soon withdrew from the process. At one time,
          Sun made most of its Java implementations available without charge,
          despite their proprietary software status. Sun generated revenue from
          Java through the selling of licenses for specialized products such as
          the Java Enterprise System. On November 13, 2006, Sun released much of
          its Java virtual machine as free, open-source software. On May 8,
          2007, Sun finished the process, making all of its JVM’s core code
          available under open-source distribution terms.
          <hr></hr>
          <p> <b>
          JAVA was developed by James Gosling at Sun Microsystems Inc in the
          year 1995, later acquired by Oracle Corporation.
          <div class="p-3 mb-2 bg-warning text-Light">
            It is a simple programming language. Java makes writing, compiling,
            and debugging programming easy. It helps to create reusable code and
            modular programs. Java is a class-based, object-oriented programming
            language and is designed to have as few implementation dependencies
            as possible.
          </div>
          A general-purpose programming language made for developers to write
          once run anywhere that is compiled Java code can run on all platforms
          that support Java. Java applications are compiled to byte code that
          can run on any Java Virtual Machine. The syntax of Java is similar to
          c/c++.</b>
        </p>


        
   

    <hr></hr>
  </div>
</div>



<hr></hr>

      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px"  }}>
            <img
              src="https://hackr.io/blog/best-way-to-learn-java/thumbnail/large"
              class="img-fluid"
              alt="menu image"
            />
          </div>
          <div class="menu-text">
            <h2 class="main-title text-left">OOPS with java</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                <u>
                  {" "}
                  <h5> TOPIC </h5>{" "}
                </u>{" "}
              </p>
            </div>

            <div class="menu-content d-flex space-between">
              <p class="menu-name">Complete JAVA Course Tutorial (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=eTXd89t8ngI&list=PLd3UqWTnYXOmx_J1774ukG_rvrpyWczm0"
                class="link-info"
                target="_blank"
              >
                Complete Java Tutorial (Videos)
              </a>
            </div>
            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table-secondary">
                <thead>
                  <tr>
                    <th scope="col">name of websites</th>
                    <th scope="col">...</th>
                  </tr>
                  <tr>
                    <td>JavaDoc</td>

                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://docs.oracle.com/javase/8/docs/api/"
                        target="_blank"
                      >
                        click here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>java T point</td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/java-tutorial"
                        target="_blank"
                      >
                        click here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>Digital Ocean</td>
                    <td>-----------------------</td>
                    <td>

                      <a
                        href="https://www.digitalocean.com/community/tutorials/core-java-tutorial"
                        target="_blank"
                      >
                        click here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>GURU99</td>
                    <td>-----------------------</td>
                    <td>

                      <a
                        href="https://www.guru99.com/java-tutorial.html"
                        target="_blank"
                      >
                        click here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>GeeksforGeeks</td>
                    <td>-----------------------</td>

                    <td>

                      <a
                        href="https://www.geeksforgeeks.org/java/?ref=shm"
                        target="_blank"
                      >
                        click here
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>W3School</td>
                    <td>-----------------------</td>

                    <td>
                      <a
                        href="https://www.w3schools.com/java/default.asp"
                        target="_blank"
                      >
                        click here
                      </a>
                    </td>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Java;
