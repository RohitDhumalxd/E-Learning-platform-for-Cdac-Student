import logo from "./logo.svg";
import "./App.css";
import Base from "./Components/Base";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import About from "./Components/About";
import Services from "./Pages/Services" ;
import Contactus from "./Pages/Contactus" ;
import Java from "./Pages/Java";
import DB from "./Pages/DB";
import NoSQL from "./Pages/NoSQL"
import SQL from "./Pages/MySQL"
import MySQL from "./Pages/MySQL";
import { AdvanceJava } from "./Pages/AdvanceJava";
import { Aptitude } from "./Pages/Aptitude";







function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Base />} />
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/about" element={<About />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contactus" element={<Contactus />} />
        <Route path="/java" element={<Java />} />
        <Route path="/DB" element={<DB />} />
        <Route path="/NoSQl" element={<NoSQL />} />
        <Route path="/MySQL" element={<MySQL />} />
        <Route path="/AdvanceJava" element={<AdvanceJava />} />
        <Route path="/Aptitude" element={<Aptitude />} />



        
        

      </Routes>
    </BrowserRouter>
  );
}

export default App;
