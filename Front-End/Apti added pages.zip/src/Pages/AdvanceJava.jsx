import React from 'react'
import './User.css';


export const AdvanceJava = () => {
    return (
      <div class="mb-5" >
      <div class="p-3 mb-2  text-dark">
        <h1 id='java'> Object Oriented Programming (OOPs)</h1>
      </div>
  
     
  <div class="container ">
  <div className="card bg-dark text-white  mx-md-n8 ">
  <img src="https://cdn.pixabay.com/photo/2017/10/31/19/05/web-design-2906159_960_720.jpg" class="card-img img-fluid" alt="..."/>
  <div class="card-img-overlay mt-5">
      <h1 id='innerjava'>Java</h1>
    <h3 class="card-title">HistoryAbout Java :</h3>
    <p class="card-text" > <b>Java’s history is very interesting. It is a
          programming language created in 1991. James Gosling, Mike Sheridan,
          and Patrick Naughton, a team of Sun engineers known as the Green team
          initiated the Java language in 1991. Sun Microsystems released its
          first public implementation in 1996 as Java 1.0. It provides no-cost
          -run-times on popular platforms. Java1.0 compiler was re-written in
          Java by Arthur Van Hoff to strictly comply with its specifications.
          With the arrival of Java 2, new versions had multiple configurations
          built for different types of platforms.</b></p> <br />
          In 1997, Sun Microsystems approached the ISO standards body and later
          formalized Java, but it soon withdrew from the process. At one time,
          Sun made most of its Java implementations available without charge,
          despite their proprietary software status. Sun generated revenue from
          Java through the selling of licenses for specialized products such as
          the Java Enterprise System. On November 13, 2006, Sun released much of
          its Java virtual machine as free, open-source software. On May 8,
          2007, Sun finished the process, making all of its JVM’s core code
          available under open-source distribution terms.
          <hr></hr>
          <p> <b>
          JAVA was developed by James Gosling at Sun Microsystems Inc in the
          year 1995, later acquired by Oracle Corporation.
          <div class="p-3 mb-2  text-Light">
            It is a simple programming language. Java makes writing, compiling,
            and debugging programming easy. It helps to create reusable code and
            modular programs. Java is a class-based, object-oriented programming
            language and is designed to have as few implementation dependencies
            as possible.
          </div>
          A general-purpose programming language made for developers to write
          once run anywhere that is compiled Java code can run on all platforms
          that support Java. Java applications are compiled to byte code that
          can run on any Java Virtual Machine. The syntax of Java is similar to
          c/c++.</b>
        </p>
    <hr></hr>
  </div>
  </div>
  </div>
  
  
  
  <hr></hr>
  
      <div class="container">
        <div class="d-flex justify-content-start">
          <div class="menu-image" style={{ padding: "20px" ,marginTop:"5px" }}>
            <img
              src="https://hackr.io/blog/best-way-to-learn-java/thumbnail/large"
              class="img-fluid"
              alt="#"
            />
          </div>
          <div class="menu-text">
            <h2 class="main-title text-left">OOPS with java</h2>
            <hr class="hr-style-left" />
            <div class="menu-content d-flex space-between">
              <p class="menu-name">
                {" "}
                <u>
                  {" "}
                  <h5> TOPIC </h5>{" "}
                </u>{" "}
              </p>
            </div>
  
            <div class="menu-content d-flex space-between">
              <p class="menu-name">Complete JAVA Course Tutorial (Videos)</p>
              <a
                href="https://www.youtube.com/watch?v=eTXd89t8ngI&list=PLd3UqWTnYXOmx_J1774ukG_rvrpyWczm0"
                class="link-info"
                target="_blank" rel="noopener noreferrer"
              >
                Complete Java Tutorial (Videos) by DurgaSoft
              </a>
            </div>
            <hr></hr>
            <div class="menu-content d-flex space-between ">
              <table class="table table-striped  table-hover">
                <thead>
                  <tr>
                    <th scope="col">Name of websites</th>
                    <th scope="col"></th>
                    <th scope="col">Links</th>
                  </tr>
                  <tr>
                    <td>JavaDoc</td>
  
                    <td>----------------------- </td>
                    <td>
                    <a href="https://docs.oracle.com/javase/8/docs/api/" className="btn btn-secondary btn-sm"   target='_blank' rel="noopener noreferrer">Click Here</a>
                     
                    </td>
                  </tr>
  
                  <tr>
                    <td>Java-T-Point</td>
                    <td>-----------------------</td>
                    <td>
                      <a
                        href="https://www.javatpoint.com/java-tutorial" className="btn btn-secondary btn-sm" 
                        target="_blank" rel="noopener noreferrer"
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>Digital Ocean</td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://www.digitalocean.com/community/tutorials/core-java-tutorial"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>GURU99</td>
                    <td>-----------------------</td>
                    <td>
  
                      <a
                        href="https://www.guru99.com/java-tutorial.html"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                       Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>GeeksforGeeks</td>
                    <td>-----------------------</td>
  
                    <td>
  
                      <a
                        href="https://www.geeksforgeeks.org/java/?ref=shm"
                        target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
  
                  <tr>
                    <td>W3School</td>
                    <td>-----------------------</td>
  
                    <td>
                      <a
                        href="https://www.w3schools.com/java/default.asp"
                        target="_blank"  rel="noopener noreferrer" className="btn btn-secondary btn-sm" 
                      >
                        Click Here
                      </a>
                    </td>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    )
  }