import React from "react";
import { useNavigate } from "react-router-dom";

const DB = () => {
  const navigate = useNavigate();

  const NoSQL = () => {
    navigate("/NoSQL");
  };

  const MySQL = () => {
    navigate("/SQL");
  };
  return (
    <div class="p-5 mb-4 pt-3 bg-dark text-white  ">
      <div style={{ paddig: "10px" }}>
        <h1 class="p-3 mb-4 pt-3 bg-secondary text-white text-center">
          DATABASE (<u>MySQL</u> & <u>No-SQL</u>) 
        </h1>
      </div>

     


      <div class="container overflow-hidden">
        <div class="row gx-5">
          <div class="col">
            <div class="p-3 border bg-dark text-center"> MY SQL </div>
            <img  src="https://static.javatpoint.com/mysql/images/mysqlandor1.png" class="img-fluid pt-3" alt="..."></img>
            <div class="d-grid gap-2 col-6 mx-auto pt-4">
              <button class="btn btn-primary" type="submit" onClick={MySQL}>
                Expore More
              </button>
            </div>
          </div>

          <div class="col">
            <div class="p-3 border bg-dark text-center">No SQL</div>
            <img  src="https://webimages.mongodb.com/_com_assets/cms/kuzt9r42or1fxvlq2-Meta_Generic.png" class="img-fluid pt-3" alt="..."></img>
            <div class="d-grid gap-2 col-6 mx-auto pt-4">
              <button class="btn btn-primary" type="submit" onClick={NoSQL}>
                Expore More
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DB;
