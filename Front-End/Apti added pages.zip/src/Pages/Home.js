import Base from "../Components/Base";
import { useNavigate } from 'react-router-dom';



const Home = () => {

const navigate = useNavigate();


const userJava =()=>{
  
  navigate("/java")
}

const DB=()=>{
  navigate("/DB")
}

  return (
    <div style={{padding:"12px"}} >
    <div>
      <Base>
      
        <div class="p-3 mb-2 bg-secondary text-dark">
          <div class="card-group">
            <div class="card ">
              <img
                class="card-img-top"
                src="https://media.istockphoto.com/photos/operating-system-word-cloud-picture-id514403369?s=612x612"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Operating System</h5>
                <p class="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
          
                <div class="col-md-12 text-center">
                <button type="button" class="btn btn-outline-secondary btn-lg"   onClick={userJava} > <u><b> More </b> </u> </button>
                </div>

              </div>
              <div class="card-footer">
                <small class="text-muted"> <b style={{color:"#CC3636"}}> Click More </b> to learn more about <b style={{color:"#CC3636"}}>Java </b> </small>
              </div>
            </div>
            <div class="card px-2">
              <img
                class="card-img-top "
                src="https://liongueststudios.com/wp-content/uploads/2021/01/Object-Oriented-Programming-concepts-in-java-lionguest-studios.png"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">
                  Java OOP (Object-Oriented Programming)
                </h5>
                <p class="card-text">
                  This card has supporting text below as a natural lead-in to
                  additional content.
                </p>
              </div>
              <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
            </div>
            <div class="card">
              <img
                class="card-img-top"
                src="https://loiane.com/assets/images/2019/mysql-oracle-cloud.jpg"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Database</h5>
                <p class="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This card has even longer
                  content than the first to show that equal height action.
                </p>
                
              </div>
              
              <div class="col-md-12 text-center">
                <button type="button" class="btn btn-outline-secondary btn-lg"  onClick={DB}> <u><b> More </b> </u> </button>
                </div>
                <div class="card-footer">
                <small class="text-muted"> <b style={{color:"#CC3636"}}> Click More </b> to learn more about  <b style={{color:"#CC3636"}}> Database </b></small>
              </div>
            </div>
          </div>
          <hr /> <hr />








          <div class="card-group">
            <div class="card ">
              <img
                class="card-img-top"
                src="https://w10.naukri.com/mailers/2022/naukri-learning/what-is/What-is-Data-Structures-and-Algorithms.jpg"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Data Structure</h5>
                <p class="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
              </div>
              <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
            </div>
            <div class="card px-2">
              <img
                class="card-img-top "
                src="https://www.sharda.ac.in/blog/wp-content/uploads/2020/10/Latest-technologies-for-web-development2.jpg"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Web technologies</h5>
                <p class="card-text">
                  This card has supporting text below as a natural lead-in to
                  additional content.
                </p>
              </div>
              <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
            </div>
            <div class="card">
              <img
                class="card-img-top"
                src="https://ashokitech.com/uploads/course/advanced-java-online-training.jpeg"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Advanced Java </h5>
                <p class="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This card has even longer
                  content than the first to show that equal height action.
                </p>
              </div>
              <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
            </div>
          </div>
          <hr /> <hr />
          <div class="card-group">
            <div class="card ">
              <img
                class="card-img-top"
                src="https://www.howtogeek.com/wp-content/uploads/2016/05/net_top.png"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Microsoft Dot Net </h5>
                <p class="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
              </div>
              <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
            </div>
            <div class="card px-2">
              <img
                class="card-img-top "
                src="https://www.laneways.agency/wp-content/uploads/2020/09/What-are-Software-Development-Methodologies-Laneways.Agency.jpg"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Software Development Methodology </h5>
                <p class="card-text">
                  This card has supporting text below as a natural lead-in to
                  additional content.
                </p>
              </div>
              <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
            </div>
            <div class="card">
              <img
                class="card-img-top"
                src="http://www.outreacheducationinitiative.org/wp-content/uploads/2018/02/professional-clipart-professional-development-14-300x300.jpg"
                alt="Card image cap"
              />
              <div class="card-body">
                <h5 class="card-title">Aptitude</h5>
                <p class="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This card has even longer
                  content than the first to show that equal height action.
                </p>
              </div>
              <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
            </div>
          </div>
        </div>
      </Base>
    </div>
    </div>
  );
};

export default Home;
