import Base from "../Components/Base";

const Services =() => {
    return (

        <Base>
            <h1>Thhis is Services page</h1>
        </Base>

    )
}

export default Services ;