import React from 'react'

 const MySQL = () => {
  return (
    <div>SQL</div>
  )
}
export default MySQL;
