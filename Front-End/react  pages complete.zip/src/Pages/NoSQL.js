import React from 'react'

 const NoSQL = () => {
  return (
    <div>NoSQL</div>
  )
}
export default NoSQL;
