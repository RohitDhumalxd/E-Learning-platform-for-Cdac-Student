
import { myAxios } from "./helper";

 export const signUp = (student)=>{

    return myAxios.post('/api/v1/auth/signup').
    then((response)=>response.json())
}















