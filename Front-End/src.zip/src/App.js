import logo from "./logo.svg";
import "./App.css";
import Base from "./Components/Base";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import About from "./Components/About";
import Services from "./Pages/Services" ;
import Contactus from "./Pages/Contactus" ;

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Base />} />
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/about" element={<About />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contactus" element={<Contactus />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
