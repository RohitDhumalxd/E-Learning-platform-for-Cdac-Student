import { useState } from "react";
import Base from "../Components/Base";

const Signup = () => {

  //<--const[data, setData] useState({
    //name :'',
   // email : '',

 } 
  )//



  return (
    <Base>
   
      <div class="card"
      style={{padding:"50px" }}>
        <div class="card-header">
          <h1>Signup</h1>
        </div>
        <div class="card-body">
          <h5 class="card-title">Fill the Form to Registration !</h5>

          <div class="row g-3">
            <div class="col">
              <label class="form-label">First name</label>
              <input
                type="text"
                class="form-control"
                placeholder="First name"
                aria-label="First name"
                required
              />
            </div>
            <div class="col">
              <label class="form-label">Last name</label>
              <input
                type="text"
                class="form-control"
                placeholder="Last name"
                aria-label="Last name"
              />
            </div>

            <form class="row g-3">
              <div class="col-md-6">
                <label for="inputEmail4" class="form-label">
                  Email
                </label>
                <input type="email" class="form-control" id="inputEmail4" />
              </div>

              <div class="col-md-6">
                <label for="inputPassword4" class="form-label">
                  Password
                </label>
                <input
                  type="password"
                  class="form-control"
                  id="inputPassword4"
                />
              </div>
              <div class="col-md-6">
                <label for="inputPassword4" class="form-label">
                  {" "}
                  Confirm Password
                </label>
                <input
                  type="password"
                  class="form-control"
                  id="inputPassword4"
                />
              </div>

              <div class="col-md-6">
                <label for="inputCity" class="form-label">
                  DOB
                </label>
                <input type="date" class="form-control" id="inputCity" />
              </div>

              <div class="col-md-6">
                <label for="inputCity" class="form-label">
                  City
                </label>
                <input type="text" class="form-control" id="inputCity" />
              </div>
              <div class="col-md-4">
                <label for="inputState" class="form-label">
                  State
                </label>
                <select id="inputState" class="form-select">
                  <option selected>Choose...</option>
                  <option value="Andhra Pradesh">Andhra Pradesh</option>
                  <option value="Andaman and Nicobar Islands">
                    Andaman and Nicobar Islands
                  </option>
                  <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                  <option value="Assam">Assam</option>
                  <option value="Bihar">Bihar</option>
                  <option value="Chandigarh">Chandigarh</option>
                  <option value="Chhattisgarh">Chhattisgarh</option>
                  <option value="Dadar and Nagar Haveli">
                    Dadar and Nagar Haveli
                  </option>
                  <option value="Daman and Diu">Daman and Diu</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Lakshadweep">Lakshadweep</option>
                  <option value="Puducherry">Puducherry</option>
                  <option value="Goa">Goa</option>
                  <option value="Gujarat">Gujarat</option>
                  <option value="Haryana">Haryana</option>
                  <option value="Himachal Pradesh">Himachal Pradesh</option>
                  <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                  <option value="Jharkhand">Jharkhand</option>
                  <option value="Karnataka">Karnataka</option>
                  <option value="Kerala">Kerala</option>
                  <option value="Madhya Pradesh">Madhya Pradesh</option>
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Manipur">Manipur</option>
                  <option value="Meghalaya">Meghalaya</option>
                  <option value="Mizoram">Mizoram</option>
                  <option value="Nagaland">Nagaland</option>
                  <option value="Odisha">Odisha</option>
                  <option value="Punjab">Punjab</option>
                  <option value="Rajasthan">Rajasthan</option>
                  <option value="Sikkim">Sikkim</option>
                  <option value="Tamil Nadu">Tamil Nadu</option>
                  <option value="Telangana">Telangana</option>
                  <option value="Tripura">Tripura</option>
                  <option value="Uttar Pradesh">Uttar Pradesh</option>
                  <option value="Uttarakhand">Uttarakhand</option>
                  <option value="West Bengal">West Bengal</option>
                </select>
              </div>
              <div class="col-md-2">
                <label for="inputZip" class="form-label">
                  Zip-Code
                </label>
                <input type="text" class="form-control" id="inputZip" />
              </div>
              <div class="col-md-4">
                <label for="inputState" class="form-label">
                  Security Question 
                </label>
                <select id="inputState" class="form-select">
                  <option selected>Choose...</option>
                  <option value="pet"> What is your first pet name ?</option>
                  <option value="bestfriend">Best friend </option>
                  <option value="town">Name of town where you were born</option>
                  <option value="Mother's maiden name">
                    Mother's maiden name
                  </option>
                  <option value="car">Your Dream car </option>
                </select>
                <label for="inputCity" class="form-label">
                  Answer
                </label>
                <input type="text" class="form-control" id="inputCity" />
              </div>
   
              <div class="col-12 text-center " >
                
                <button type="submit" class="btn btn-dark btn-lg"
                > 
                  Signup
                </button>
                <button type="reset" class="btn btn-dark btn-lg"
                style={{margin:"30px" }} >
                  Reset 
                </button>
              </div>


              
            </form>
          </div>
        </div>
      </div>
      
    </Base>
  );
};

export default Signup;
