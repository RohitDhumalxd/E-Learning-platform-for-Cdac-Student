import CustomNavbar from "./CustomNavbar";

const Base=({ title = "Welcome to our website", children }) => {
    return (
        <div className="container-fluid p-0 m-0">
            <CustomNavbar />

            {children}

            <h1>This is footer</h1>
        </div>

    );
};

export default Base;

/* we have made this base component,using this base component we can maintain common header
 and footer on every page on whichever page we want. */