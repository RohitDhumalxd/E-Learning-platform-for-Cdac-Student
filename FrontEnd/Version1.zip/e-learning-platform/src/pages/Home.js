import Base from "../components/Base"

const Home=()=>{
    return(
        <Base>
        <div>
        <h1>This is home page</h1>
        <p>Welcome to home page</p>
        </div>
        </Base>
    )
}
export default Home