import { useEffect, useState } from "react";
import { signUp } from "../services/student_service";
import { Button, Card, CardBody, CardHeader, Container, Form, FormGroup, Input, Label } from "reactstrap";
import Base from "../components/Base";

const Signup=()=>{


   const [data,setData]=useState({
      name:'',
      email:'',
      password:'',
      phone:'',
      security_question:'',
      security_answer:'',
   })

   const [error,setError]=useState({
      errors:{},
      isError:false
     
   })

   
   useEffect(()=>{
      console.log(data);
   },[data])


   //handle change
   const handleChange=(event,property)=>{

      //dynamic setting the values
      setData({...data,[property]:event.target.value})
   }

   //resetting the form
   const resetData=()=>{
      setData({
      name:'',
      email:'',
      password:'',
      phone:'',
      security_question:'',
      security_answer:'',
      })
   }

   //submitting the form
   const submitForm=(event)=>{
      event.preventDefault()

      console.log(data);
      //data validate


      //call server api for sending the data
      signUp(data).then((resp) => {
         console.log(resp);
         console.log("success log");
      }).catch((error)=>{
         console.log(error)
         console.log("Error log")
      })
      
      ;
   };


    return(
        <Base>
        <div>
       
       <Container>
         {JSON.stringify(data)}
        <Card>
            <CardHeader>
               <h3> Fill Information to register !! </h3>

               <CardBody>

                <Form onSubmit={submitForm}>
                    {/* Name filed */}
                    <FormGroup>
                       <Label for="name">Enter Name</Label>
                       <Input
                       type="text"
                       placeholder="Enter here"
                       id="name"
                       onChange={(e)=>handleChange(e,'name')}
                       value={data.name}
                       />
                    </FormGroup>

                        {/* email filed */}
                    <FormGroup>
                       <Label for="email">Enter Email</Label>
                       <Input
                       type="email"
                       placeholder="Enter here"
                       id="email"
                       onChange={(e)=>handleChange(e,'email')}
                       value={data.email}
                       />
                    </FormGroup>
                    <FormGroup>
                       <Label for="password">Enter Password</Label>
                       <Input
                       type="password"
                       placeholder="Enter here"
                       id="password"
                       onChange={(e)=>handleChange(e,'password')}
                       value={data.password}
                       />
                    </FormGroup>
                    <FormGroup>
                       <Label for="phone">Enter Phone</Label>
                       <Input
                       type="tel"
                       placeholder="Enter here"
                       id="phone"
                       onChange={(e)=>handleChange(e,'phone')}
                       value={data.phone}
                       />
                    </FormGroup>
                    <FormGroup>
                       <Label for="security_question">Security Question</Label>
                       <Input
                       type="security_question"
                       placeholder="What is your favourite animal?"
                       id="security_question"
                       onChange={(e)=>handleChange(e,'security_question')}
                       />
                    </FormGroup>
                    <FormGroup>
                       <Label for="security_answer">Enter Answer</Label>
                       <Input
                       type="security_answer"
                       placeholder="Enter here"
                       id="security_answer"
                       onChange={(e)=>handleChange(e,'security_answer')}
                       />
                    </FormGroup>
                 
                    <Container className="text-center">
                        <Button color="dark">Register</Button>
                        <Button onClick={resetData} color="secondary" className="ms-2">Reset</Button>
                    </Container>





                </Form>
               </CardBody>





            </CardHeader>
        </Card>
       </Container>





        </div>
        </Base>
    )
}
export default Signup