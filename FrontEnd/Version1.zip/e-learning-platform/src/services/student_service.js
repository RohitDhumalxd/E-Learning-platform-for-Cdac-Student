import { myAxios } from "./helper";

export const signUp=(student)=>{


    return myAxios.post('/api/students/',student).then((response)=> response.data);
}