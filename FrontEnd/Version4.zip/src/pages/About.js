import Base from "../components/Base"


const About = () => {
    return (
        <Base>
        <h1>This is about page</h1>
        <p>we are building e-learning website</p>
        </Base>
    );
};

export default About;