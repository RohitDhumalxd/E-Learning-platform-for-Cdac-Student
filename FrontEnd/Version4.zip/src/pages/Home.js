import Base from "../components/Base"
import React from "react"
import Hero from "../home/Hero"


const Home = () => {
    return(
        <Base>
        <div>
            <Hero />
       
        </div>
        </Base>
    )
}
export default Home