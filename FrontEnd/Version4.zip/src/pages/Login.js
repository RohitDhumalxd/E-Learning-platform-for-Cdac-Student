import {Button,Card, CardBody, CardHeader, Container, Row,Col,FormGroup, Input, Label} from "reactstrap"
import Base from "../components/Base"

const Login=()=>{
    return(
       <Base>
       
       <Container>

        <Row className="mt-4">
            <Col sm={
                {
                    size:6,
                    offset:3
                }
            }>

                <Card color="secondary" inverse>

                    <CardHeader>

                        <h3>Login Here !!</h3>

                    </CardHeader>

                    <CardBody>
                          {/* email filed */}
                    <FormGroup>
                       <Label for="email">Enter Email</Label>
                       <Input
                       type="email"
                       placeholder="Enter here"
                       id="email"
                       />
                    </FormGroup>
                    <FormGroup>
                       <Label for="password">Enter Password</Label>
                       <Input
                       type="password"
                       placeholder="Enter here"
                       id="password"
                       />
                    </FormGroup>

                    <Container className="text-center">
                        <Button color="dark" outline>Register</Button>
                        <Button color="light" className="ms-2" outline>Reset</Button>
                    </Container>


                    </CardBody>



                </Card>
            </Col>
        </Row>
     </Container>
 </Base>
    )
}
export default Login