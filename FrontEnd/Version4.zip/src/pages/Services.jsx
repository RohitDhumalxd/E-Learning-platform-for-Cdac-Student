import Base from "../components/Base"

const Services=()=>{
    return(
        <Base>
        <div>
        <h1>This is Services page</h1>
       
        </div>
        </Base>
    )
}
export default Services